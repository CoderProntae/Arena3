#!/usr/bin/env python3
"""Ephemeral outbound-only relay for a user-operated Windows Studio MCP client.

PUBLIC: authenticated /worker/* endpoints. PRIVATE: /admin/* needs a
DIFFERENT random secret, never placed in the Windows client package.
There is no general proxy, remote shell, file server or arbitrary URL fetch.
"""
from __future__ import annotations

from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
import base64
import html
import json
import os
import re
import secrets
import threading
import time
import uuid

ROOT = Path(__file__).resolve().parent
PORT = int(os.environ.get("BRIDGE_PORT", "8765"))
WORKER_TOKEN = (ROOT / "worker_token.txt").read_text(encoding="utf-8").strip()
ADMIN_TOKEN = (ROOT / "admin_token.txt").read_text(encoding="utf-8").strip()
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
MAX_BYTES = 24 * 1024 * 1024
READ_TOOLS = frozenset({
    "list_roblox_studios", "get_studio_state", "search_game_tree",
    "inspect_instance", "script_search", "script_grep", "script_read",
    "get_console_output", "screen_capture",
})
APPROVAL_TOOLS = frozenset({
    "start_stop_play", "execute_luau", "multi_edit", "character_navigation",
    "user_mouse_input", "user_keyboard_input",
})
ALLOWED_TOOLS = READ_TOOLS | APPROVAL_TOOLS

state = {
    "hello": 0.0, "last_seen": 0.0, "capabilities": [],
    "worker_info": "", "polls": 0, "jobs": {}, "queue": deque(),
}
cv = threading.Condition()


def collect_images(obj: object, job_id: str) -> list[str]:
    """Only decode MCP image content returned by screen_capture, never a path from input."""
    found: list[str] = []
    def walk(node: object, depth: int = 0) -> None:
        if depth > 10 or len(found) >= 4:
            return
        if isinstance(node, list):
            for item in node:
                walk(item, depth + 1)
        elif isinstance(node, dict):
            if (node.get("type") == "image" or
                    str(node.get("mimeType", "")).startswith("image/")):
                mime = str(node.get("mimeType", ""))
                suffix = ".png" if "png" in mime else ".jpg"
                encoded = node.get("data")
                if isinstance(encoded, str) and len(encoded) < MAX_BYTES:
                    try:
                        blob = base64.b64decode(encoded, validate=True)
                        valid = blob.startswith(b"\x89PNG\r\n\x1a\n") or blob.startswith(b"\xff\xd8\xff")
                        if valid and len(blob) <= 12 * 1024 * 1024:
                            output = RESULTS / f"{job_id}_{len(found) + 1}{suffix}"
                            output.write_bytes(blob)
                            found.append(str(output))
                    except (ValueError, base64.binascii.Error):
                        pass
            for key, value in node.items():
                if key not in {"data", "text"}:
                    walk(value, depth + 1)
    walk(obj)
    return found


class Handler(BaseHTTPRequestHandler):
    server_version = "StudioBridge/1"
    def log_message(self, fmt: str, *args: object) -> None:
        # No tokens or response payloads go into server logs.
        if not self.path.startswith("/worker/poll"):
            print(f"[relay] {self.address_string()} {fmt % args}", flush=True)

    def reply(self, code: int, payload: object, content_type: str = "application/json") -> None:
        if content_type == "application/json":
            body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        else:
            body = str(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def authorized(self, role: str) -> bool:
        secret = WORKER_TOKEN if role == "worker" else ADMIN_TOKEN
        supplied = self.headers.get("Authorization", "")
        expected = "Bearer " + secret
        return secrets.compare_digest(supplied, expected)

    def get_json(self) -> dict | None:
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > MAX_BYTES:
                self.reply(413, {"error": "JSON body size out of bounds"})
                return None
            obj = json.loads(self.rfile.read(size))
            if not isinstance(obj, dict):
                self.reply(400, {"error": "Expected JSON object"})
                return None
            return obj
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
            self.reply(400, {"error": "Malformed JSON"})
            return None

    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        path = parsed.path
        if path == "/":
            with cv:
                active = time.time() - state["last_seen"] < 30
                cap = len(state["capabilities"])
            status = "CONNECTED" if active else "NOT CONNECTED"
            page = ("<!doctype html><meta charset='utf-8'><title>Studio bridge</title>"
                    "<style>body{font:17px system-ui;background:#131a28;color:#eef;"
                    "max-width:680px;margin:6rem auto;padding:2rem}h1{color:#99ddff}"
                    "small{color:#b6c0ce}</style><h1>Roblox Studio MCP bridge</h1>"
                    f"<p>Windows client: <strong>{html.escape(status)}</strong></p>"
                    f"<p>Advertised Studio tools: {cap}</p>"
                    "<small>No Studio commands are accepted through this page. "
                    "Only the user-run local client can talk to Studio.</small>")
            self.reply(200, page, "text/html")
            return
        if path.startswith("/admin/") and not self.authorized("admin"):
            self.reply(401, {"error": "Authentication required"})
            return
        if path == "/admin/state":
            with cv:
                data = {"connected": time.time() - state["last_seen"] < 30,
                        "last_seen": state["last_seen"],
                        "hello": state["hello"],
                        "worker_info": state["worker_info"],
                        "tools": [t.get("name") for t in state["capabilities"]],
                        "pending": list(state["queue"]),
                        "jobs": [{"id": j["id"], "tool": j["tool"],
                                  "status": j["status"], "images": j.get("images", [])}
                                 for j in state["jobs"].values()]}
            self.reply(200, data)
            return
        if path == "/admin/tools":
            with cv:
                tools = state["capabilities"]
            self.reply(200, {"tools": tools})
            return
        if path in ("/admin/result", "/admin/wait"):
            query = parse_qs(parsed.query)
            job_id = query.get("id", [""])[0]
            with cv:
                job = state["jobs"].get(job_id)
                if path == "/admin/wait" and job:
                    try:
                        seconds = min(110, max(1, int(query.get("seconds", ["65"])[0])))
                    except ValueError:
                        seconds = 65
                    cv.wait_for(lambda: job["status"] == "done", timeout=seconds)
                if job:
                    info = {"id": job_id, "tool": job["tool"],
                            "status": job["status"],
                            "response_file": job.get("file"),
                            "images": job.get("images", []),
                            "elapsed": round(time.time() - job["created"], 1)}
                else:
                    info = None
            self.reply(200 if info else 404, info or {"error": "No such request"})
            return
        self.reply(404, {"error": "Not found"})

    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        if path.startswith("/worker/"):
            if not self.authorized("worker"):
                self.reply(401, {"error": "Worker authentication required"})
                return
        elif path.startswith("/admin/"):
            if not self.authorized("admin"):
                self.reply(401, {"error": "Admin authentication required"})
                return
        else:
            self.reply(404, {"error": "Not found"})
            return
        obj = self.get_json()
        if obj is None:
            return
        if path == "/worker/hello":
            tools = obj.get("tools")
            if (not isinstance(tools, list) or len(tools) > 200 or
                    not all(isinstance(t, dict) and isinstance(t.get("name"), str)
                            for t in tools)):
                self.reply(400, {"error": "Invalid Studio tool list"})
                return
            with cv:
                state["capabilities"] = tools
                state["hello"] = state["last_seen"] = time.time()
                state["worker_info"] = str(obj.get("client", ""))[:160]
                cv.notify_all()
            print(f"[relay] Studio MCP worker online with {len(tools)} tools", flush=True)
            self.reply(200, {"ok": True})
            return
        if path == "/worker/poll":
            with cv:
                state["last_seen"] = time.time()
                state["polls"] += 1
                if not state["queue"]:
                    cv.wait(timeout=8.0)
                state["last_seen"] = time.time()
                job = None
                if state["queue"]:
                    job_id = state["queue"].popleft()
                    job = state["jobs"][job_id]
                    job["status"] = "sent"
            if job:
                self.reply(200, {"job": {"id": job["id"],
                                          "tool": job["tool"],
                                          "arguments": job["arguments"],
                                          "approval": job["tool"] in APPROVAL_TOOLS}})
            else:
                self.reply(200, {"job": None,
                                 "needs_hello": not bool(state["capabilities"])})
            return
        if path == "/worker/result":
            job_id = obj.get("id")
            if not isinstance(job_id, str) or not re.fullmatch(r"[0-9a-f]{32}", job_id):
                self.reply(400, {"error": "Bad request id"})
                return
            with cv:
                job = state["jobs"].get(job_id)
                if not job or job["status"] != "sent":
                    self.reply(404, {"error": "Request was not sent or no longer exists"})
                    return
                reply_path = RESULTS / f"{job_id}.json"
                reply_path.write_text(json.dumps(obj, ensure_ascii=False,
                    indent=2), encoding="utf-8")
                images = (collect_images(obj.get("response"), job_id)
                          if job["tool"] == "screen_capture" else [])
                job["file"] = str(reply_path)
                job["images"] = images
                job["status"] = "done"
                cv.notify_all()
            print(f"[relay] completed {job['tool']} -> {job_id}", flush=True)
            self.reply(200, {"ok": True, "images": images})
            return
        if path == "/admin/queue":
            name = obj.get("tool")
            args = obj.get("arguments", {})
            if not isinstance(name, str) or not isinstance(args, dict):
                self.reply(400, {"error": "Expected tool name and object arguments"})
                return
            with cv:
                known = {t["name"] for t in state["capabilities"]}
                if time.time() - state["last_seen"] >= 30:
                    self.reply(503, {"error": "Windows client is not currently connected"})
                    return
                if name not in ALLOWED_TOOLS or name not in known:
                    self.reply(403, {"error": "Not advertised or not allowed"})
                    return
                job_id = uuid.uuid4().hex
                state["jobs"][job_id] = {"id": job_id, "tool": name,
                    "arguments": args, "created": time.time(), "status": "queued"}
                state["queue"].append(job_id)
                cv.notify_all()
            print(f"[relay] queued {name} -> {job_id}", flush=True)
            self.reply(200, {"id": job_id,
                             "needs_local_approval": name in APPROVAL_TOOLS})
            return
        self.reply(404, {"error": "Not found"})


def main() -> None:
    httpd = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    httpd.daemon_threads = True
    print(f"[relay] listening on 0.0.0.0:{PORT} (worker authenticated; admin separately authenticated)",
          flush=True)
    try:
        httpd.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
